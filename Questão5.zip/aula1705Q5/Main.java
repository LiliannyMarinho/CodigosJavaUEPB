package aula1705Q5;

public class Main {

	public static void main(String[] args) {
		
		Teclado tec = new Teclado("ZONE");
		Monitor monit = new Monitor("SAMSUNG Gamer Odyssey 49 QLED, 120 Hz, Ultra Wide, DQHD, HDMI/DisplayPort, 125% sRGB, HDR 1000");
		PlacaMae p_m = new PlacaMae("ASUS TUF GAMING A520M-PLUS II");
		Computador comp = new Computador("DELL",tec,monit,p_m);
		comp.setTec(tec);
		comp.setMonit(monit);
		comp.setP_m(p_m);
		
		System.out.println(comp.toString());
	}

}
